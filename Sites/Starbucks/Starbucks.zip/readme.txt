Information are stored in /root/facebookusers.txt
